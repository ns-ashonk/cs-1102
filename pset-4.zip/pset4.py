# ============================================================
# Problem 4-1: Selection Sort
# ============================================================

def find_min_index(L, start):
    """Find index of smallest element"""
    min_idx = start
    for j in range(start + 1, len(L)):
        if L[j] < L[min_idx]:
            min_idx = j
    return min_idx


def selection_sort(L):
    """Sort list using selection sort"""
    assert isinstance(L, list)  # input must be list

    n = len(L)

    for i in range(n):
        # prefix is sorted so far
        min_idx = find_min_index(L, i)  # find min in suffix
        L[i], L[min_idx] = L[min_idx], L[i]  # swap into place

    # verify sorted order
    for k in range(n - 1):
        assert L[k] <= L[k + 1]

    return L


# ============================================================
# Problem 4-2: Iterative Factorial
# ============================================================

def factorial(n):
    """Compute factorial iteratively"""
    assert isinstance(n, int) and n >= 0  # valid input only

    result = 1  # start with 1
    i = 1       # loop counter

    while i <= n:
        # result equals (i-1)!
        result *= i  # multiply current value
        i += 1       # move to next

    return result  # returns n!


# ============================================================
# Problem 4-3: Chunk-wise List Reversal
# ============================================================

def chunk_reverse(L, k):
    """Reverse order of chunks"""
    assert isinstance(L, list)  # L must be list
    assert isinstance(k, int) and 1 < k < len(L)  # valid k

    n = len(L)

    # split list into chunks
    chunks = []
    for i in range(0, n, k):
        chunks.append(L[i:i+k])

    result = []  # store final output

    # append chunks in reverse order
    for i in range(len(chunks) - 1, -1, -1):
        result.extend(chunks[i])

    # verify permutation property
    assert sorted(result) == sorted(L)

    return result


# ============================================================
# Problem 4-4: Alternating List Merge
# ============================================================

def alternate_merge(L1, L2):
    """Merge lists in alternating order"""
    assert isinstance(L1, list) and isinstance(L2, list)  # valid inputs

    result = []  # store merged list
    i = 0
    min_len = min(len(L1), len(L2))  # shorter length

    while i < min_len:
        # append alternating elements
        result.append(L1[i])
        result.append(L2[i])
        i += 1

    # append remaining elements
    if len(L1) > len(L2):
        result.extend(L1[i:])
    else:
        result.extend(L2[i:])

    # verify total length
    assert len(result) == len(L1) + len(L2)

    return result


# ============================================================
# Test Runs (Optional)
# ============================================================

'''
print(selection_sort([32, 104, -5, 17, 81]))
print(factorial(5))
print(chunk_reverse([1,2,3,4,5,6,7,8,9], 3))
print(alternate_merge([1,3,5], [2,4,6,8]))
'''

print(selection_sort([32, 104, -5, 17, 81]))
print(factorial(5))
print(chunk_reverse([1,2,3,4,5,6,7,8,9],3))
print(alternate_merge([1,3,5], [2,4,6,8]))