def is_sorted(values):
    """Return True when the list is in nondecreasing order."""
    for index in range(len(values) - 1):
        if values[index] > values[index + 1]:
            return False
    return True


# ── Problem 4-1: Selection Sort ──────────────────────────────────────────────

def selection_sort(values):
    assert isinstance(values, list), "selection_sort expects a list"
    original = values.copy()
    n = len(values)

    for i in range(n):
        # Outer loop invariant
        assert is_sorted(values[:i])
        assert all(values[p] <= values[q] for p in range(i) for q in range(i, n))

        min_index = i
        for j in range(i + 1, n):
            # Inner loop invariant
            assert all(values[min_index] <= values[k] for k in range(i, j))
            if values[j] < values[min_index]:
                min_index = j

        assert all(values[min_index] <= values[k] for k in range(i, n))
        values[i], values[min_index] = values[min_index], values[i]

    # Postconditions
    assert is_sorted(values)
    assert sorted(values) == sorted(original)


# ── Problem 4-2: Iterative Factorial ─────────────────────────────────────────

def factorial(n):
    # Precondition
    assert isinstance(n, int) and n >= 0, "factorial expects a non-negative integer"

    result = 1
    i = 1

    while i <= n:
        # Loop invariant: result == (i - 1)!
        assert result == __builtins__['__import__']('math').factorial(i - 1) if isinstance(__builtins__, dict) \
            else __import__('math').factorial(i - 1), "invariant broken"
        result *= i
        i += 1

    # Postcondition: result == n!
    import math
    assert result == math.factorial(n)
    return result


# ── Problem 4-3: Chunk-wise List Reversal ────────────────────────────────────

def chunk_reverse(L, k):
    # Preconditions
    assert isinstance(L, list), "chunk_reverse expects a list"
    assert isinstance(k, int) and 1 < k < len(L), "k must satisfy 1 < k < len(L)"

    chunks = [L[i:i + k] for i in range(0, len(L), k)]
    m = len(chunks)
    result = []

    for i in range(m - 1, -1, -1):
        # Loop invariant: result == chunks[m-1] + ... + chunks[i+1]
        assert result == sum((chunks[j] for j in range(m - 1, i, -1)), [])
        result.extend(chunks[i])

    # Postcondition: same elements, chunks reversed
    assert sorted(result) == sorted(L)
    return result


# ── Problem 4-4: Alternating List Merge ──────────────────────────────────────

def alternating_merge(L1, L2):
    # Preconditions
    assert isinstance(L1, list), "L1 must be a list"
    assert isinstance(L2, list), "L2 must be a list"

    result = []
    min_len = min(len(L1), len(L2))
    i = 0

    while i < min_len:
        # Loop invariant: result == [L1[0], L2[0], ..., L1[i-1], L2[i-1]]
        assert len(result) == 2 * i
        assert all(result[2*t] == L1[t] and result[2*t + 1] == L2[t] for t in range(i))
        result.append(L1[i])
        result.append(L2[i])
        i += 1

    # Tail phase: append remaining elements from the longer list
    if len(L1) > len(L2):
        result.extend(L1[min_len:])
    else:
        result.extend(L2[min_len:])

    # Postcondition
    assert len(result) == len(L1) + len(L2)
    return result


# ── Tests ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # 4-1
    data = [32, 104, -5, 17, 81, 993, 12, -109, 266, 5]
    selection_sort(data)
    print("4-1 Selection Sort:   ", data)

    # 4-2
    for n in range(8):
        print(f"4-2 Factorial({n}):     {factorial(n)}")

    # 4-3
    print("4-3 Chunk Reverse:    ", chunk_reverse([1, 2, 3, 4, 5, 6, 7, 8, 9], 3))
    print("4-3 Chunk Reverse:    ", chunk_reverse([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3))

    # 4-4
    print("4-4 Alternating Merge:", alternating_merge([1, 3, 5], [2, 4, 6]))
    print("4-4 Alternating Merge:", alternating_merge([1, 3, 5, 7], [2, 4]))