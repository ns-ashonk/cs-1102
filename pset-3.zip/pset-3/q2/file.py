# Problem 3-2. The One With a Peak [30 points]

''' Consider a list of n elements. We say an index i is a peak if the element at position i is strictly
greater than both of its neighbors. You may assume that both ends of the lists are bordered by
negative infinity. Write a code to return all the peaks and provide a proof of the correctness of the
code. '''

def peak_finder(m):
    peaks = []
    index_list = []
    k = len(m)

    for i in range(k):
        if i == 0:
            if m[i] > m[i+1]:
                peaks.append(m[i])
                index_list.append(i)

        elif i == k - 1:
            if m[i] > m[i-1]:
                peaks.append(m[i])
                index_list.append(i)

        else:
            if m[i-1] < m[i] > m[i+1]:
                peaks.append(m[i])
                index_list.append(i)

    print("The peaks of this list are:", peaks)
    print("The indexes of these peaks are:", index_list)

def main():
    n = int(input("Enter number of elements: "))
    m = []
    for i in range(n):
        e = int(input("Enter element: "))
        m.append(e)
    peak_finder(m)

main()