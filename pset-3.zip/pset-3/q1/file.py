# (a) Reversal
def reverse_list(m):
    print("Reversed list:", m[::-1])


# (b) Chunk Reversal
def chunk_reversal(m, k):
    if k <= 1 or k >= len(m):
        raise ValueError("k must satisfy 1 < k < n")
    
    result = []
    for i in range(0, len(m), k):
        result.extend(m[i:i+k][::-1])
    
    return result


# (c) Splitting - equal consecutive chunks
def split_list(m, k):
    if k <= 1 or k >= len(m):
        raise ValueError("k must satisfy 1 < k < n")
    
    new_list = []
    n = len(m)
    
    size = n // k
    extra = n % k
    
    count = 0
    temp = []
    
    for i in range(len(m)):
        temp.append(m[i])
        count += 1
        
        # Check if current sublist is full
        if len(new_list) < extra:
            limit = size + 1
        else:
            limit = size
        
        if count == limit:
            new_list.append(temp)
            temp = []
            count = 0
    
    return new_list


# (d) Deletion
def deletion(m, k):
    if k <= 0:
        raise ValueError("k must be positive")
    
    new_list = []
    
    for i in range(len(m)):
        if (i + 1) % k != 0:
            new_list.append(m[i])
    
    return new_list


def main():
    n = int(input("Enter number of elements: "))
    m = [int(input("Enter element: ")) for _ in range(n)]
    
    print("\nChoose operation:")
    print("1. Reverse")
    print("2. Chunk Reversal")
    print("3. Splitting")
    print("4. Deletion")
    
    choice = int(input("Enter choice: "))
    
    if choice == 1:
        reverse_list(m)
    
    elif choice == 2:
        k = int(input("Enter k: "))
        print(chunk_reversal(m, k))
    
    elif choice == 3:
        k = int(input("Enter k: "))
        print(split_list(m, k))
    
    elif choice == 4:
        k = int(input("Enter k: "))
        print(deletion(m, k))


main()