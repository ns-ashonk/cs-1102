# (a) Reversal
def reverse_list(m):
    print("Reversed list:", m[::-1])


# (b) Chunk Reversal
def chunk_reversal(m):
    k = int(input("Enter k: "))
    result = []
    
    for i in range(0, len(m), k):
        result.extend(m[i:i+k][::-1])
    
    print("After chunk reversal:", result)


# (c) Splitting
def split_list(m):
    k = int(input("Enter k: "))
    
    if k <= 1 or k >= len(m):
        print("k must satisfy 1 < k < n")
        return
    
    result = []
    
    for i in range(0, len(m), k):
        result.append(m[i:i+k])
    
    print("After splitting:", result)


# (d) Deletion
def deletion(m):
    k = int(input("Enter k: "))
    
    result = []
    
    for i in range(len(m)):
        if (i + 1) % k != 0:
            result.append(m[i])
    
    print("After deletion:", result)


# MAIN
def main():
    n = int(input("Enter number of elements: "))
    m = []
    
    for i in range(n):
        element = int(input("Enter element: "))
        m.append(element)
    
    print("\nChoose operation:")
    print("1. Reverse")
    print("2. Chunk Reversal")
    print("3. Splitting")
    print("4. Deletion")
    
    choice = int(input("Enter choice: "))
    
    if choice == 1:
        reverse_list(m)
    elif choice == 2:
        chunk_reversal(m)
    elif choice == 3:
        split_list(m)
    elif choice == 4:
        deletion(m)
    else:
        print("Invalid choice")


main()