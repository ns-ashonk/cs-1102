# Problem 2-2: Take a left to go right [20 points]
# Take an image - a rectangular one - and turn it:
# ================================================

# (a) [10 points] Clockwise by 90 degrees
# ================================================

import numpy as np
from PIL import Image

def readImage(filename):
    img = Image.open(filename, 'r')
    width, height = img.size
    pix = list(img.getdata())
    return [pix[n:n+width] for n in range(0, width*height, width)], width, height

def writeImage(image_out, filename):
    pix = []
    height = len(image_out)
    width  = len(image_out[0])
    for i in range(height):
        for j in range(width):
            pix += [(int(image_out[i][j][0]), int(image_out[i][j][1]), int(image_out[i][j][2]))]
    outputIm = Image.new("RGB", (width, height))
    outputIm.putdata(pix)
    outputIm.save(filename, "JPEG")

# original (row, col) --> new (col, height-1-row)
# dimensions flip: new_height = width, new_width = height

def rotateCW(image):
    height = len(image)
    width  = len(image[0])

    # output has swapped dimensions
    out = [[(0, 0, 0)] * height for _ in range(width)]

    for row in range(height):
        for col in range(width):
            out[col][height - 1 - row] = image[row][col]

    return out

def rotateCCW(image):
    height = len(image)
    width  = len(image[0])

    out = [[(0, 0, 0)] * height for _ in range(width)]

    for row in range(height):
        for col in range(width):
            out[width - 1 - col][row] = image[row][col]

    return out





