# Problem 2-3: Reshaping reality (kind of) [40 points]
# ================================================================================================
# (c) [10 points] Take a note of all the safety checks/edge cases that you have implemented.


# ============================================================
#
#  1. Negative origin: x < 0 or y < 0               → error, return None
#  2. Origin out of image: x >= img_width etc.       → error, return None
#  3. Non-positive crop size: w <= 0 or h <= 0       → error, return None
#  4. Crop box exceeds image edge                    → warning, clamp w/h
#  5. Non-positive display size: displayW/H <= 0     → error, return None
#  6. crop() returning None propagates up cleanly    → cropAndResize returns None
#
#  The only intentional silent behavior is clamping (case 4) since
#  "crop as much as possible" is more useful than hard-failing there.

# ============================================================



