# Problem 2-3: Reshaping reality (kind of) [40 points]
# ================================================================================================
# (b) [15 points] Additionally, take two more values display W and display H and
# produce a stretched/squeezed image. That is, the cropped bit of the image of
# width w and height h, should now be stretched/squeezed into a new image of
# width display W and height display H.

from PIL import Image

def readImage(filename):
    img = Image.open(filename, 'r')
    width, height = img.size
    pix = list(img.getdata())
    return [pix[n:n+width] for n in range(0, width*height, width)], width, height

def writeImage(image_out, filename):
    pix = []
    height = len(image_out)
    width  = len(image_out[0])
    for i in range(height):
        for j in range(width):
            pix += [(int(image_out[i][j][0]), int(image_out[i][j][1]), int(image_out[i][j][2]))]
    outputIm = Image.new("RGB", (width, height))
    outputIm.putdata(pix)
    outputIm.save(filename, "JPEG")

def crop(image, x, y, w, h):
    img_height = len(image)
    img_width  = len(image[0])

    # --- safety checks ---
    if x < 0 or y < 0:
        print(f"Error: crop origin ({x}, {y}) is out of bounds.")
        return None
    if x >= img_width or y >= img_height:
        print(f"Error: crop origin ({x}, {y}) is outside the image ({img_width}x{img_height}).")
        return None
    if w <= 0 or h <= 0:
        print(f"Error: crop dimensions must be positive. Got w={w}, h={h}.")
        return None

    # clamp w and h so the crop box doesn't spill past the image edge
    if x + w > img_width:
        print(f"Warning: crop width exceeds image boundary. Clamping from {w} to {img_width - x}.")
        w = img_width - x
    if y + h > img_height:
        print(f"Warning: crop height exceeds image boundary. Clamping from {h} to {img_height - y}.")
        h = img_height - y

    out = [[(0, 0, 0)] * w for _ in range(h)]

    for row in range(h):
        for col in range(w):
            out[row][col] = image[y + row][x + col]

    return out


# ============================================================
# Crop + stretch/squeeze to display W x display H
# ============================================================
# For each pixel (row, col) in the output, map BACK to the
# corresponding source pixel in the cropped image:
#   src_row = int(row * h / displayH)
#   src_col = int(col * w / displayW)
# This avoids gaps that forward-mapping can leave.

def cropAndResize(image, x, y, w, h, displayW, displayH):

    # --- safety checks on display dimensions ---
    if displayW <= 0 or displayH <= 0:
        print(f"Error: display dimensions must be positive. Got {displayW}x{displayH}.")
        return None

    cropped = crop(image, x, y, w, h)
    if cropped is None:
        return None

    # update w/h in case crop() clamped them
    actual_h = len(cropped)
    actual_w = len(cropped[0])

    out = [[(0, 0, 0)] * displayW for _ in range(displayH)]

    for row in range(displayH):
        for col in range(displayW):
            src_row = int(row * actual_h / displayH)
            src_col = int(col * actual_w / displayW)
            out[row][col] = cropped[src_row][src_col]

    return out

