# Problem 2-3: Reshaping reality (kind of) [40 points]
# ================================================================================================
# (a) [15 points] Take any image, a point P=(x, y), and two values w and h and
# produce a cropped image, where the top left corner is P, and which has width
# w and height h.

from PIL import Image

def readImage(filename):
    img = Image.open(filename, 'r')
    width, height = img.size
    pix = list(img.getdata())
    return [pix[n:n+width] for n in range(0, width*height, width)], width, height

def writeImage(image_out, filename):
    pix = []
    height = len(image_out)
    width  = len(image_out[0])
    for i in range(height):
        for j in range(width):
            pix += [(int(image_out[i][j][0]), int(image_out[i][j][1]), int(image_out[i][j][2]))]
    outputIm = Image.new("RGB", (width, height))
    outputIm.putdata(pix)
    outputIm.save(filename, "JPEG")

# ============================================================
# Crop
# ============================================================
# P = (x, y) is the top-left corner of the crop box
# x is column offset, y is row offset (standard image convention)
# output is a new image of size w x h

def crop(image, x, y, w, h):
    img_height = len(image)
    img_width  = len(image[0])

    # --- safety checks ---
    if x < 0 or y < 0:
        print(f"Error: crop origin ({x}, {y}) is out of bounds.")
        return None
    if x >= img_width or y >= img_height:
        print(f"Error: crop origin ({x}, {y}) is outside the image ({img_width}x{img_height}).")
        return None
    if w <= 0 or h <= 0:
        print(f"Error: crop dimensions must be positive. Got w={w}, h={h}.")
        return None

    # clamp w and h so the crop box doesn't spill past the image edge
    if x + w > img_width:
        print(f"Warning: crop width exceeds image boundary. Clamping from {w} to {img_width - x}.")
        w = img_width - x
    if y + h > img_height:
        print(f"Warning: crop height exceeds image boundary. Clamping from {h} to {img_height - y}.")
        h = img_height - y

    out = [[(0, 0, 0)] * w for _ in range(h)]

    for row in range(h):
        for col in range(w):
            out[row][col] = image[y + row][x + col]

    return out



