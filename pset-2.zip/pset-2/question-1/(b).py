# Problem 2-1: Socialize with other pixels [40 points]
# ================================================================================================

# (b) [20 points] Then, modify it to use any odd n > 1. Even numbers should be rejected with an error message.
# ============================================================================================================


# ============================================================
# General n×n convolution (any odd n > 1)
# ============================================================

def multiplyN(pixel, kernel, i, j, n):
    height = len(pixel)
    width  = len(pixel[0])
    pad = n // 2
    R, G, B = 0, 0, 0

    if i < pad or j < pad or i >= height - pad or j >= width - pad:
        R = pixel[i][j][0]
        G = pixel[i][j][1]
        B = pixel[i][j][2]
    else:
        for ki in range(n):
            for kj in range(n):
                R += pixel[i - pad + ki][j - pad + kj][0] * kernel[ki][kj]
                G += pixel[i - pad + ki][j - pad + kj][1] * kernel[ki][kj]
                B += pixel[i - pad + ki][j - pad + kj][2] * kernel[ki][kj]

    R = max(0, min(255, int(R)))
    G = max(0, min(255, int(G)))
    B = max(0, min(255, int(B)))
    return (R, G, B)

def convolveN(image, kernel):
    n = len(kernel)

    if n % 2 == 0:
        print(f"Error: kernel size must be odd. Got {n}.")
        raise ValueError("Kernel size must be odd.")
    if n <= 1:
        print(f"Error: kernel size must be greater than 1. Got {n}.")
        raise ValueError("Kernel size must be greater than 1")

    height = len(image)
    width  = len(image[0])
    return [[multiplyN(image, kernel, i, j, n) for j in range(width)] for i in range(height)]