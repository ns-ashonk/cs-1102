# Problem 2-1: Socialize with other pixels [40 points]
# ================================================================================================

# (a) [20 points] Take the code for convolving with a 3 by 3 kernel and modify it to use a 5 by 5.
# ================================================================================================

from PIL import Image

# Reads image file and store RGB values in a 2-d array
def readImage(filename):
    img = Image.open(filename, 'r')
    width, height = img.size
    pix = list(img.getdata())
    return [pix[n:n+width] for n in range(0, width*height, width)], width, height

# Writes a 2-d array of RGB values to an image file
def writeImage(image_out, filename):
    pix = []
    height = len(image_out)
    width  = len(image_out[0])
    for i in range(height):
        for j in range(width):
            pix += [(int(image_out[i][j][0]), int(image_out[i][j][1]), int(image_out[i][j][2]))]
    outputIm = Image.new("RGB", (width, height))
    outputIm.putdata(pix)
    outputIm.save(filename, "JPEG")


# ============================================================
# 5×5 convolution
# ============================================================

def multiply5x5(pixel, kernel, i, j):
    height = len(pixel)
    width  = len(pixel[0])
    R, G, B = 0, 0, 0

    if i < 2 or j < 2 or i >= height - 2 or j >= width - 2:
        R = pixel[i][j][0]
        G = pixel[i][j][1]
        B = pixel[i][j][2]
    else:
        for ki in range(5):
            for kj in range(5):
                R += pixel[i - 2 + ki][j - 2 + kj][0] * kernel[ki][kj]
                G += pixel[i - 2 + ki][j - 2 + kj][1] * kernel[ki][kj]
                B += pixel[i - 2 + ki][j - 2 + kj][2] * kernel[ki][kj]

    R = max(0, min(255, int(R)))
    G = max(0, min(255, int(G)))
    B = max(0, min(255, int(B)))
    return (R, G, B)

def convolve5x5(image, kernel):
    height = len(image)
    width  = len(image[0])
    return [[multiply5x5(image, kernel, i, j) for j in range(width)] for i in range(height)]
